package testcases;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC_002CreateLead extends BaseClass{
	
	@Test
	public void runCreateLead() {
	
		new LoginPage(driver)
		.enterUsername()
	    .enterPassword()
	    .clickLoginButton()
	    .verifyHomePage()
	    .clickCrmsfaLink()
	    .clickLeadsLink()
	    .clickCreateLeadLink()
	    .enterCompanyName()
	    .enterFirstName()
	    .enterLastName()
	    .clickSubmitButton()
	    .verifyCreateLead();
		
		
		

	}

}
