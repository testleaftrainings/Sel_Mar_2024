package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends BaseClass{
	
	@Given("Enter the username as {string}")
	public void enter_the_username(String uName) {
		driver.findElement(By.id("username")).sendKeys(uName);
	}

	@Given("Enter the password as {string}")
	public void enter_the_password(String pWord) {
		driver.findElement(By.id("password")).sendKeys(pWord);
	}

	@When("Click on the Login Button")
	public void click_on_the_login_button() {
		driver.findElement(By.className("decorativeSubmit")).click();
	}

}
