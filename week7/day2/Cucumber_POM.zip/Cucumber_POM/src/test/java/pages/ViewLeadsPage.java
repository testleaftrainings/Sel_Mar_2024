package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.Then;

public class ViewLeadsPage extends BaseClass{

	


	@Then("Leadid should be displayed as (.*)$")
	public void leadid_should_be_displayed(String cName) {
		String text = driver.findElement(By.xpath("//span[text()='Company Name']/following::span")).getText();
		if (text.contains(cName)) {
			System.out.println("Lead is verified");
		}
		else {
			System.out.println("Not verified");
		}

	}



}
