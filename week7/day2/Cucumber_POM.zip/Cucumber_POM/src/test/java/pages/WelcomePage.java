package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class WelcomePage extends BaseClass{
	
	@Then("HomePage should be displayed")
	public void home_page_should_be_displayed() {
		String text = driver.findElement(By.tagName("h2")).getText();
		if (text.contains("Welcome")) {
			System.out.println("HomePage is displayed");
		}
		else {
			System.out.println("Homepage is not displayed");
		}
	}


	@But("ErrorMessage should be displayed")
	public void error_message_should_be_displayed() {
		String text = driver.findElement(By.id("errorDiv")).getText();
		if (text.contains("Errors")) {
			System.out.println("Error message is displayed");
		}
		else {
			System.out.println("Error message is not displayed");
		}
	}
	

	@When("Click on crmsfa link")
	public void click_on_crmsfa_link() {
		driver.findElement(By.partialLinkText("CRM")).click();
	}

}
