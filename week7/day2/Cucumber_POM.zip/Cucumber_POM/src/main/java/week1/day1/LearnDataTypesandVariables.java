package week1.day1;

public class LearnDataTypesandVariables {

	public static void main(String[] args) {
		//  datatype variable = value	
		byte  age  = 25; // default value : 0 
		short distance  = 1000; // default value : 0 
		int  pincode  = 600073; // default value : 0
		long phoneNumber=9876543210l;// default value : 0l
		float temperature = 98.2f; // default value : 0.0f
		double bankBalance = 5000.839283;// default value : 0.0
		char  logo = 'H';// default value : '\u0000'
		String brandName = "Honda"; // // default value :null
		boolean isJavaPlatformInd=true;// default value : false
		
		System.out.println("Age is: "+age);
		System.out.println(distance + " " +pincode + " " +phoneNumber + " " +temperature);
		System.out.println("Bank balance is : "+bankBalance);
		System.out.println(logo);
		System.out.println(brandName);
		System.out.println(isJavaPlatformInd);
		
		





	}

}
