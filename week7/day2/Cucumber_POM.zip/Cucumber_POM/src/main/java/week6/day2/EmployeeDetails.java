package week6.day2;

public class EmployeeDetails {
	
	
	public int empId;
	public String empName;
	public boolean empStatus;
	
	/*
	 * Constructor -> is used to initialize the state of an object
	 * The Constructor name and the class name will be similar
	 * It is similar to the method but there should not be any return type / void
	 * Types of Constructor
	 *   Default Constructor - implicit/explicit
	 *   Parameterized Constructor - Constructor overloading
	 * this -> it is a keyword refers to the current class instance
	 *      -> It can be used to differentiate between the local variable and the global variable if it has the same name  
	 * Can you call one constructor from another constructor ? Yes , Constructor Chaining
	 *   Constructor Chaining can be achieved using this keyword
	 *   Constructor call must be the first statement in a constructor
	 * 
	 */
	public EmployeeDetails(){
		this(200, "S", true);
		System.out.println("Default Constructor");
		
		
	}
	
	public EmployeeDetails(int empId, String empName,boolean empStatus){
		//this();
		System.out.println("Parameterized Constructor");
		this.empId=empId;
		this.empName=empName;
		this.empStatus=empStatus;
		
	}
	
	
	
	
	public static void main(String[] args) {
		//EmployeeDetails ed = new EmployeeDetails(200, "Vidhya", true);
		EmployeeDetails ed1 = new EmployeeDetails();
		
		System.out.println(ed1.empId + "\n" + ed1.empName +"\n" +ed1.empStatus);
	}

}
