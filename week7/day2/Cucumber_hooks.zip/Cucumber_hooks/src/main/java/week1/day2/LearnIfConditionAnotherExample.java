package week1.day2;

public class LearnIfConditionAnotherExample {
	public static void main(String[] args) {
		char grade = 'D';
		
		if (grade == 'A') {
			System.out.println("Excellent");
		}
		else if(grade == 'B') {
			System.out.println("Good Job!");
		}
		else if(grade == 'C') {
			System.out.println("Need Improvement");
		}
		else {
			System.out.println("Sorry ! You Failed");
		}

	}

}
