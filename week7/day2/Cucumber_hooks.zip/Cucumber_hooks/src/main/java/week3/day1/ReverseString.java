package week3.day1;

public class ReverseString {
	
	public static void main(String[] args) {
		String str = "Subraja";
		// convert the given String to charArray
		// iterate through the char array through a reverse loop
		// print the array
		
	}

}
