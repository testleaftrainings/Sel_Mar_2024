package week3.day2;

public  class Bank {
	
	

	public static void main(String[] args) {
		AxisBank ab = new AxisBank();
		ab.knowYourCustomer();
		
		
		
	}


}
