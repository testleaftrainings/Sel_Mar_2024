package runner;

import io.cucumber.testng.CucumberOptions;
import steps.BaseClass;


@CucumberOptions(features={"src/test/java/features"},
                 glue={"steps"},
                 monochrome=true,
                 publish=true,
               //  tags="@smoke") // executes only the particular scenario
               //  tags="@regression or @functional") //executes either scenarios
               //   tags="@smoke and @functional")// exceutes the scenario which has both together
                    tags = "not @regression")// to exclude a scenario from execution
public class CucumberRunner extends BaseClass{

}
