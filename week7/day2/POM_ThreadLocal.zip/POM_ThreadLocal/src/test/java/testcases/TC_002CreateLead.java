package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC_002CreateLead extends BaseClass{
	
	@BeforeTest
	public void setValues() {
		fileName="CreateLead";

	}
	
	@Test(dataProvider = "fetchData")
	public void runCreateLead(String uName,String pWord,String cName,String fName,String lName) {
	
		new LoginPage()
		.enter_the_username(uName)
		.enter_the_password(pWord)
		.click_on_the_login_button()
		.home_page_should_be_displayed()
		.click_on_crmsfa_link()
		.click_on_the_leads_link()
		.click_on_the_create_lead_link()
		.enter_the_companyname(cName)
		.enter_the_firstname(fName)
		.enter_the_lastname(lName)
		.click_on_the_submit_button()
		.leadid_should_be_displayed(cName);
		
		

	}

}
