package base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadData;

public class BaseClass extends AbstractTestNGCucumberTests{
	
	//public static ChromeDriver driver;
	
	private static final ThreadLocal<RemoteWebDriver> rDriver = new ThreadLocal<>();
	
	
	public void setDriver(String browser) {
		if (browser.equalsIgnoreCase("chrome")) {
			rDriver.set(new ChromeDriver());
		}
		else if (browser.equalsIgnoreCase("edge")) {
			rDriver.set(new EdgeDriver());
		}
		else if (browser.equalsIgnoreCase("firefox")) {
			rDriver.set(new FirefoxDriver());
		}
		

	}
	
	public RemoteWebDriver getDriver() {
		return rDriver.get();
	}
	
	
	public String fileName;
	
    @Parameters("browser")
	@BeforeMethod
	public void preCondition(String browser) {
		setDriver(browser);
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		getDriver().get("http://leaftaps.com/opentaps/control/main");
	}
	
	@AfterMethod
	public void postCondition() {
		getDriver().quit();

	}
	
	@DataProvider(name="fetchData",parallel=true,indices=1)
	public String[][] sendData() throws IOException {
		return ReadData.readData(fileName);

	}
}
