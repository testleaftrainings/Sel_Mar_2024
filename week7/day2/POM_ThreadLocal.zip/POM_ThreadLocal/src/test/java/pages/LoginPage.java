package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends BaseClass{
	
	@Given("Enter the username as {string}")
	public LoginPage enter_the_username(String uName) {
		getDriver().findElement(By.id("username")).sendKeys(uName);
		return this;
	}

	@Given("Enter the password as {string}")
	public LoginPage enter_the_password(String pWord) {
		getDriver().findElement(By.id("password")).sendKeys(pWord);
		return this;
	}

	@When("Click on the Login Button")
	public WelcomePage click_on_the_login_button() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		return new WelcomePage();
	}

}
