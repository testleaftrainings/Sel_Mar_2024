package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.When;

public class MyLeadsPage extends BaseClass{
	
	@When("Click on the createLead link")
	public CreateLeadPage click_on_the_create_lead_link() {
		getDriver().findElement(By.linkText("Create Lead")).click();
		return new CreateLeadPage();
	}
}
