package week3.day2;

public class SBIBank implements RBI{

	public void goldLoan() {
		System.out.println("5% interest rate");
	}
	
	@Override
	public void knowYourCustomer() {
		System.out.println("AADHAR");
		
	}
	
    @Override
	public void repoRate() {
		// TODO Auto-generated method stub
		
	}
	

	public void cibilScore() {
		System.out.println("8");
		
	}

	
	public int withDrawalLimit() {
		
		return 25000;
	}
	






}
