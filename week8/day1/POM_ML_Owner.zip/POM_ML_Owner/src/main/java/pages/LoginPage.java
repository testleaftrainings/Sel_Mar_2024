package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import config.Configuration;

public class LoginPage extends BaseClass{
	
	
	public LoginPage(ChromeDriver driver){
		this.driver=driver;
	}

	public LoginPage enterUsername() {
		
		driver.findElement(By.id("username")).sendKeys(Configuration.configuration().getUsername());
		return this;
	}

	public LoginPage enterPassword() {
		driver.findElement(By.id("password")).sendKeys(Configuration.configuration().getPassword());
		return this;
	}

	public WelcomePage clickLoginButton() {
		driver.findElement(By.className("decorativeSubmit")).click();
		return new WelcomePage(driver);
	}

}
