package config;

import org.aeonbits.owner.ConfigCache;

public class Configuration {
	
	public static ConfigurationManager configuration() {
		return ConfigCache.getOrCreate(ConfigurationManager.class);

	}

}
