package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

public class BaseClass {

	public  ChromeDriver driver;
	public static Properties prop,prop1;
	public static String useVal,passVal,welValue;

	@Parameters("language")
	@BeforeMethod
	public void preCondition(String lang) throws IOException {
		
		if (lang.equalsIgnoreCase("en")) {
			FileInputStream fis = new FileInputStream("src/main/resources/config.en.properties");
			prop = new Properties();
			prop.load(fis);
			useVal = prop.getProperty("username");
			passVal = prop.getProperty("password");
			welValue = prop.getProperty("welcometext");
		}
		else if (lang.equalsIgnoreCase("fr")) {
			FileInputStream fis1 = new FileInputStream("src/main/resources/config.fr.properties");
			prop1 = new Properties();
			prop1.load(fis1);
			useVal = prop1.getProperty("username");
			passVal = prop1.getProperty("password");
			welValue = prop1.getProperty("welcometext");
		}
		
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("http://leaftaps.com/opentaps/control/main");

	}

	@AfterMethod
	public void postCondition() {
		driver.close();

	}

}
