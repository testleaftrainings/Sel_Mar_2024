package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;

public class WelcomePage extends BaseClass{
	
	
	public WelcomePage(ChromeDriver driver){
		this.driver=driver;
	}
	
	public WelcomePage verifyHomePage() {
		
		String text = driver.findElement(By.tagName("h2")).getText();
		if (text.contains(welValue)) {
			System.out.println("HomePage is displayed");
		}
		else {
			System.out.println("HomePage is not displayed");
		}
		return this;

	}
	
	public MyHomePage clickCrmsfaLink() {
		driver.findElement(By.partialLinkText("CRM")).click();
		return new MyHomePage(driver);

	}

}
