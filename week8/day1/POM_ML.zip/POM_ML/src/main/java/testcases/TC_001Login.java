package testcases;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC_001Login extends BaseClass{
	
	@Test
	public void runLogin() {
		
		
		new LoginPage(driver)
		.enterUsername()
		.enterPassword()
		.clickLoginButton()
		.verifyHomePage();
		

	}

}
